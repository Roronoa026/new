@extends('layout')
@section('content')
@section('title')
Production form
@endsection
<form method="post" action="/create">
	<input type="hidden" name="_token" value="<?php echo csrf_token();?>">
		Name : <input type="text" name="Name"><br>
		Password : <input type="password" name="Pass"><br>
		<input type="submit">
 <h4>Didn't have a account signup here</h4> SignUp <a href="create.blade.php">;
	</form>
	@endsection