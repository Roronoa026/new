@extends('employees.layout')
@section('content')
  
<div class="card" style="margin:20px;">
  <div class="card-header">Edit employee</div>
  <div class="card-body">
       
      <form action="{{ url('employee/' .$employees->id) }}" method="post">
        {!! csrf_field() !!}
        @method("PATCH")
        <input type="hidden" name="id" id="id" value="{{$employees->id}}" id="id" />
        <label>Name</label></br>
        <input type="text" name="name" id="name" value="{{$employees->name}}" class="form-control"></br>
        <label>Password</label></br>
        <input type="password" name="Password" id="Password" value="{{$employees->Password}}" class="form-control"></br>
        <label>Email</label></br>
        <input type="text" name="Email" id="Email" value="{{$employees->Email}}" class="form-control"></br>
        <label>Department</label></br>
        <input type="text" name="Department" id="Department" value="{{$employees->Department}}" class="form-control"></br>
        <label>Designation</label></br>
        <input type="text" name="Designation" id="Designation" value="{{$employees->Designation}}" class="form-control"></br>
        <label>Date of joining</label></br>
        <input type="text" name="dateofjoining" id="dateofjoining" value="{{$employees->Dateofjoining}}" class="form-control"></br>
        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>
    
  </div>
</div>
  
@stop