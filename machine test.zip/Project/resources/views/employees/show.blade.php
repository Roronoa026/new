@extends('employees.layout')
@section('content')
  
<div class="card" style="margin:20px;">
  <div class="card-header">Employees Page</div>
  <div class="card-body">
        <div class="card-body">
        <h5 class="card-title">Name : {{ $employees->Name }}</h5>
        <p class="card-text">Email : {{ $employees->Email }}</p>
        <p class="card-text">Department : {{ $employees->Department}}</p>
        <p class="card-text">Designation : {{ $employees->Designation}}</p>
        <p class="card-text">Date of joining : {{ $employees->Dateofjoining}}</p>
  </div>
    </hr>
  </div>
</div>