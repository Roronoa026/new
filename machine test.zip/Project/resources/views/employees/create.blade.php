@extends('employees.layout')
@section('content')
  
<div class="card" style="margin:20px;">
  <div class="card-header">Create New Employees</div>
  <div class="card-body">
       
      <form action="{{ url('employees') }}" method="post">
        {!! csrf_field() !!}
        <label>Name</label></br>
        <input type="text" name="Name" id="Name" action="required" class="form-control"></br>
        <label>Email</label></br>
        <input type="text" name="Email" id="Email" action="required" class="form-control"></br>
        <label>epartmentword</label></br>
        <input type="password" name="Password" id="Pass" action="required" class="form-control"></br>
        <label>Department</label></br>
        <input type="text" name="Department" id="Department" action="required" class="form-control"></br>
        <label>Designation</label></br>
        <input type="text" name="Designation" id="Designation" action="required" class="form-control"></br>
        <label>Date of joining</label></br>
        <input type="text" name="Dateofjoining" id="Dateofjoining" action="required" class="form-control"></br>
        
        <input type="submit" value="Save" class="btn btn-success"></br>
    </form>
    
  </div>
</div>
  
@stop